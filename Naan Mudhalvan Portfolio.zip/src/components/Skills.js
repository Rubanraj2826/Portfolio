import React from 'react';

const Skills = () => (
  <section id="skills">
    <h2>Skills</h2>
    <ul>
      <li>HTML</li>
      <li>CSS</li>
      <li>JavaScript</li>
      <li>React.js</li>
      <li>node js</li>
    </ul>
    <a className='top' href='#head'>Back to top</a>
  </section>
);

export default Skills;