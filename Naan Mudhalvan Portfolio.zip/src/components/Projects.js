import React from 'react';

const Projects = () => (
  <section id="projects">
    <h2>Projects</h2>
    <div>
      
      <h3>Car Website</h3>
      <p>A basic car website built with HTML and CSS, featuring a footer bar, product page, About page and nav bar.</p>

      
    </div>
    <a className='top' href='#head'>Back to top</a>
  </section>
);

export default Projects;

