import React from 'react';

const Contact = () => (
  <section id="contact">
    <h2>Contact</h2>
    <p><b>Email:</b> rubanrajpgpcet@gmail.com</p>
    <p><b>LinkedIn:</b> https://www.linkedin.com/in/rubanraj-m-2826rk
    </p>
    <a className='top' href='#head'>Back to top</a>
  </section>
);

export default Contact;
